import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-epargne',
  templateUrl: './epargne.page.html',
  styleUrls: ['./epargne.page.scss'],
})
export class EpargnePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
